# SmartSpend AI — 3-minute demo script

**0:00–0:20 — Introduction**
"Hello, this is SmartSpend AI, a student finance companion designed to make everyday budgeting easier."

**0:20–0:50 — Problem**
"Students make frequent small purchases, but those expenses are easy to forget. Without a simple overview, it is difficult to understand spending patterns."

**0:50–1:40 — Live walkthrough**
"Here is the monthly budget, total spending, transaction count and daily average. I will add a new Education expense. The transaction list, category chart and totals update immediately."

**1:40–2:20 — Budget planning**
"I can set a monthly spending limit. The dashboard shows how much has been used and how much remains."

**2:20–2:50 — Explainable insights**
"The insight panel highlights the largest spending category, budget usage and a possible saving opportunity. These recommendations are rule-based in this prototype, so they are transparent and easy to verify."

**2:50–3:00 — Closing**
"SmartSpend AI helps students build better money habits through simple tracking, clear visualisation and practical guidance. Thank you."

## Before recording
- Use fictional sample expenses only.
- Do not show personal bank, UPI, email or identity information.
- Test the app and chart before recording.
- Keep the final event demo under the organiser's five-minute limit.
