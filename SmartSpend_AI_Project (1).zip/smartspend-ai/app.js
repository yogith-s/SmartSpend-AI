const $ = (id) => document.getElementById(id);
const categories = ["Food","Travel","Education","Shopping","Entertainment","Other"];
const colors = ["#4568e8","#20a67a","#ef9b45","#9a78df","#e36d8b","#8a96a8"];
const today = new Date();
const dateString = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
const sample = [
  {name:"College lunch",category:"Food",amount:120,date:dateString(today)},
  {name:"Bus fare",category:"Travel",amount:40,date:dateString(today)},
  {name:"Notebook",category:"Education",amount:85,date:dateString(new Date(today.getFullYear(),today.getMonth(),today.getDate()-1))},
  {name:"Snacks",category:"Food",amount:65,date:dateString(new Date(today.getFullYear(),today.getMonth(),today.getDate()-2))},
  {name:"Movie ticket",category:"Entertainment",amount:180,date:dateString(new Date(today.getFullYear(),today.getMonth(),today.getDate()-3))},
  {name:"T-shirt",category:"Shopping",amount:350,date:dateString(new Date(today.getFullYear(),today.getMonth(),today.getDate()-4))}
];
let transactions = JSON.parse(localStorage.getItem("ss_transactions") || "null") || sample;
let budget = Number(localStorage.getItem("ss_budget") || 5000);
let chart;
const money = n => "₹" + Math.round(n).toLocaleString("en-IN");
const thisMonth = () => transactions.filter(t => t.date.slice(0,7) === dateString(today).slice(0,7));
function save(){localStorage.setItem("ss_transactions",JSON.stringify(transactions));localStorage.setItem("ss_budget",String(budget));}
function render(){
  const rows=thisMonth(), total=rows.reduce((s,t)=>s+Number(t.amount),0), pct=budget?Math.min(100,Math.round(total/budget*100)):0;
  $("totalSpent").textContent=money(total);$("transactionCount").textContent=rows.length;
  $("dailyAverage").textContent=money(total/Math.max(1,today.getDate()));
  const food=rows.filter(t=>t.category==="Food").reduce((s,t)=>s+Number(t.amount),0);
  const shopping=rows.filter(t=>t.category==="Shopping").reduce((s,t)=>s+Number(t.amount),0);
  const potential=Math.round(shopping*.15);
  $("potentialSavings").textContent=money(potential);
  $("budgetHero").textContent=money(budget);
  $("budgetCaption").textContent=total<=budget?`${money(budget-total)} remaining this month.`:`You are ${money(total-budget)} over budget.`;
  $("budgetPercent").textContent=pct+"%";
  $("budgetRing").style.background=`conic-gradient(#8ce0c3 ${pct*3.6}deg,#ffffff40 0deg)`;
  $("budgetInput").value=budget;
  $("progressFill").style.width=pct+"%";
  $("progressFill").style.background=pct>=100?"#df6b65":pct>=80?"#ef9b45":"#20a67a";
  $("budgetStatus").textContent=pct>=100?"You have reached or exceeded your budget.":pct>=80?"You have used most of your budget. Keep an eye on new expenses.":"You are within your planned budget.";
  $("transactionRows").innerHTML=rows.slice().sort((a,b)=>b.date.localeCompare(a.date)).slice(0,7).map(t=>`<tr><td><b>${escapeHtml(t.name)}</b></td><td><span class="category-tag">${t.category}</span></td><td>${new Date(t.date+"T00:00:00").toLocaleDateString("en-IN",{day:"numeric",month:"short"})}</td><td class="right amount">${money(t.amount)}</td></tr>`).join("") || `<tr><td colspan="4">No expenses yet.</td></tr>`;
  const sums=categories.map(c=>rows.filter(t=>t.category===c).reduce((s,t)=>s+Number(t.amount),0));
  if(chart) chart.destroy();
  chart=new Chart($("categoryChart"),{type:"doughnut",data:{labels:categories,datasets:[{data:sums,backgroundColor:colors,borderWidth:0,hoverOffset:5}]},options:{responsive:true,maintainAspectRatio:false,cutout:"72%",plugins:{legend:{display:false}}}});
  $("categoryLegend").innerHTML=categories.filter((c,i)=>sums[i]>0).map(c=>`<span style="--dot:${colors[categories.indexOf(c)]}">${c}</span>`).join("");
  makeInsights(rows,total,food,shopping,pct);
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function makeInsights(rows,total,food,shopping,pct){
  const list=[];
  if(!rows.length) list.push(["Start with one expense","Add your first expense to receive a personalised spending summary."]);
  else {
    const top=categories.map(c=>({c,v:rows.filter(t=>t.category===c).reduce((s,t)=>s+Number(t.amount),0)})).sort((a,b)=>b.v-a.v)[0];
    if(top.v) list.push(["Your biggest category",`${top.c} is your highest spending category at ${money(top.v)} this month. Review whether this matches your priorities.`]);
    if(pct>=80) list.push(["Budget alert",`You have used ${pct}% of your monthly budget. Consider postponing non-essential purchases until your next budget period.`]);
    else list.push(["Budget check",`You have used ${pct}% of your monthly budget. Keep recording expenses to maintain a reliable picture.`]);
    if(shopping>0) list.push(["Saving opportunity",`A 15% reduction in your recorded Shopping spend could save approximately ${money(shopping*.15)}.`]);
    if(food>total*.5 && total>0) list.push(["Food spending pattern","Food accounts for more than half of your recorded spending. Planning meals may help you manage this category."]);
  }
  $("insightList").innerHTML=list.map(([h,p])=>`<div class="insight"><b>✧ ${h}</b><p>${p}</p></div>`).join("");
}
function openDialog(){ $("expenseDate").value=dateString(today); $("expenseDialog").showModal(); }
$("addTop").addEventListener("click",openDialog);$("addInline").addEventListener("click",openDialog);
$("expenseForm").addEventListener("submit",e=>{e.preventDefault();const name=$("expenseName").value.trim(),amount=Number($("expenseAmount").value),date=$("expenseDate").value;if(!name||amount<=0||!date)return;transactions.push({name,amount,category:$("expenseCategory").value,date});save();render();$("expenseDialog").close();$("expenseForm").reset();});
$("saveBudget").addEventListener("click",()=>{const v=Number($("budgetInput").value);if(v>0){budget=v;save();render();}});
$("resetData").addEventListener("click",()=>{if(confirm("Reset all entries to the original sample data?")){transactions=sample.slice();budget=5000;save();render();}});
render();
