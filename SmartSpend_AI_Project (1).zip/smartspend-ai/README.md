# SmartSpend AI — Student Finance Companion

SmartSpend AI is a responsive student budgeting prototype for the AI-for-finance hackathon theme. It helps students record everyday expenses, set a monthly budget, understand category-level spending and receive explainable budgeting suggestions.

## Features
- Add expenses with description, category, amount and date.
- Monthly budget planner with progress indicator.
- Spending breakdown chart.
- Recent transaction list.
- Rule-based, explainable spending insights.
- Browser local storage; no account or bank connection required.
- Responsive layout for desktop and mobile.

## Run locally
1. Download or clone this repository.
2. Open `index.html` in a modern browser.
3. Add sample expenses and change the monthly budget to test the dashboard.

The chart uses Chart.js from a CDN, so an internet connection is needed for the chart to render. The rest of the app works locally.

## Technology
- HTML5
- CSS3
- Vanilla JavaScript
- Chart.js
- Browser Local Storage

## Data and privacy
This prototype uses sample data and entries typed by the user. Data is stored in the browser's local storage on the device. It does not connect to banks, UPI apps or payment services. Do not enter real banking credentials or sensitive financial information.

## How the insights work
The current prototype uses transparent rules (top spending category, budget utilisation, and potential savings estimate). It is not connected to a generative AI model. This keeps the demo functional without API keys and makes each recommendation explainable. A future version can add an AI API after proper privacy and security review.

## Demo checklist
1. Open the dashboard.
2. Point out the monthly budget and summary cards.
3. Add an expense such as `Stationery`, ₹150, category `Education`.
4. Show the transaction list and category chart updating.
5. Change the monthly budget to ₹2,000 and save.
6. Show the budget progress and insight cards changing.

## Project status
Prototype / hackathon submission candidate. Further validation, testing and organiser-specific submission requirements must be completed before final submission.
